jpa-project
============

Illustrates usage of custom JPA entity used as process variable with persistence variable strategy use.
This project includes 
- entity
- persistence.xml
- configuration of marshaling strategy
- extension to JPA strategy to use proper class loader on read and write operation for variables
- persistence util to load entity manager factory
