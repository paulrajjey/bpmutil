package org.jbpm.process.migration.handler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jbpm.process.migration.MigrationManager;
import org.jbpm.process.migration.NodeMapping;
import org.jbpm.process.migration.ProcessData;
import org.kie.api.runtime.process.WorkItem;
import org.kie.api.runtime.process.WorkItemHandler;
import org.kie.api.runtime.process.WorkItemManager;

public class PerformActiveInstanceHandler implements WorkItemHandler {

	@SuppressWarnings("unchecked")
	public void executeWorkItem(WorkItem workItem, WorkItemManager manager) {
		ProcessData data = (ProcessData) workItem.getParameter("in_processdata");
		
		List<Long> outcome = MigrationManager.migrateAll(data);
		List<ProcessData> listMig = new ArrayList<ProcessData>();
		ProcessData newdata = null;
		for (Long val: outcome) {
			newdata = new ProcessData( data.getDeploymentId(),val,data.getToProcessId(),data.getToDeploymentId());
			listMig.add(newdata);
        }
		
		for (ProcessData processDt: listMig) {
		    System.out.println("process data" + processDt.toString());
			MigrationManager.migrate(processDt, null);
		}
		
		Map<String, Object> results = new HashMap<String, Object>();
		results.put("out_outcome", ""+listMig.size());
		
		manager.completeWorkItem(workItem.getId(), results);
	}

	public void abortWorkItem(WorkItem workItem, WorkItemManager manager) {
		// no-op

	}

}
