bpm-projects
============

Various deployable projects for jBPM
