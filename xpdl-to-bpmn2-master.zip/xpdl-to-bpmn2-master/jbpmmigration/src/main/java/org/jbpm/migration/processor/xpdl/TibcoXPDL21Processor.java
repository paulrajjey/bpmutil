package org.jbpm.migration.processor.xpdl;

import java.util.stream.Stream;

import org.jbpm.migration.processor.MigrationProcessor;
import org.jbpm.migration.processor.dom.ApplyXSLTransformationProcessor;
import org.jbpm.migration.processor.dom.GenerateBPMNEdgeProcessor;
import org.jbpm.migration.processor.dom.GenerateProcessVariablesProcessor;
import org.jbpm.migration.processor.dom.GenerateUniqueIoSpecificationIdProcessor;
import org.jbpm.migration.processor.dom.GenerateUniqueUserTaskIdProcessor;
import org.jbpm.migration.processor.dom.MultiSourceToDivergingGatewayProcessor;
import org.jbpm.migration.processor.dom.MultiTargetToConvergingGatewayProcessor;
import org.jbpm.migration.processor.dom.OverlappingPoolProcessor;
import org.jbpm.migration.processor.dom.ResizePoolProcessor;
import org.jbpm.migration.processor.dom.SanityCheckProcessor;
import org.jbpm.migration.processor.dom.SizeShapesProcessor;
import org.jbpm.migration.processor.stream.SplitProcessesProcessor;
import org.w3c.dom.Document;

/**
 * Processor to migrate TIBCO XPDL 2.1 files to BPMN2
 */
public class TibcoXPDL21Processor extends MigrationProcessor {
	private static final String XPDL_TO_BPMN2_XSL = "xpdl21/tibco/XPDLtoBPMN2.xsl";
	private final ApplyXSLTransformationProcessor applyXSLTransformationProcessor;
	private final SplitProcessesProcessor splitProcessesProcessor;
	private final GenerateProcessVariablesProcessor generateProcessVariablesProcessor;
	private final GenerateUniqueIoSpecificationIdProcessor generateUniqueIoSpecificationIdProcessor;
	private final GenerateUniqueUserTaskIdProcessor generateUniqueUserTaskIdProcessor;
	private final MultiTargetToConvergingGatewayProcessor multiTargetToConvergingGatewayProcessor;
	private final MultiSourceToDivergingGatewayProcessor multiSourceToDivergingGatewayProcessor;
	private final SizeShapesProcessor sizeShapesProcessor;
	private final ResizePoolProcessor resizePoolProcessor;
	private final OverlappingPoolProcessor overlappingPoolProcessor;
	private final GenerateBPMNEdgeProcessor generateBPMNEdgeProcessor;
	private final SanityCheckProcessor sanityCheckProcessor;
	
	public TibcoXPDL21Processor() {
		this.applyXSLTransformationProcessor = new ApplyXSLTransformationProcessor(XPDL_TO_BPMN2_XSL);
		this.splitProcessesProcessor = new SplitProcessesProcessor();
		this.generateProcessVariablesProcessor = new GenerateProcessVariablesProcessor();
		this.generateUniqueIoSpecificationIdProcessor = new GenerateUniqueIoSpecificationIdProcessor();
		this.generateUniqueUserTaskIdProcessor = new GenerateUniqueUserTaskIdProcessor();
		this.multiTargetToConvergingGatewayProcessor = new MultiTargetToConvergingGatewayProcessor();
		this.multiSourceToDivergingGatewayProcessor = new MultiSourceToDivergingGatewayProcessor();
		this.sizeShapesProcessor = new SizeShapesProcessor();
		this.resizePoolProcessor = new ResizePoolProcessor();
		this.overlappingPoolProcessor = new OverlappingPoolProcessor();
		this.generateBPMNEdgeProcessor = new GenerateBPMNEdgeProcessor();
		this.sanityCheckProcessor = new SanityCheckProcessor();
	}
	
	public Stream<Document> process(Document doc) {
		return Stream.of(doc)
				.map(applyXSLTransformationProcessor::process)
				.flatMap(splitProcessesProcessor::process)
				.map(generateProcessVariablesProcessor::process)
				.map(generateUniqueIoSpecificationIdProcessor::process)
				.map(generateUniqueUserTaskIdProcessor::process)
				.map(multiTargetToConvergingGatewayProcessor::process)
				.map(multiSourceToDivergingGatewayProcessor::process)
				.map(sizeShapesProcessor::process)
				.map(resizePoolProcessor::process)
				.map(overlappingPoolProcessor::process)
				.map(generateBPMNEdgeProcessor::process)
				.map(sanityCheckProcessor::process);
	}
}
