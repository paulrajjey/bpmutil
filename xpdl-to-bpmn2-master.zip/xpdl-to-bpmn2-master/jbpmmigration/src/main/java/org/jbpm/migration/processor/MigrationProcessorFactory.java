package org.jbpm.migration.processor;

import org.jbpm.migration.processor.xpdl.TibcoXPDL21Processor;

public class MigrationProcessorFactory {
	private static final String VENDOR_TIBCO = "TIBCO";
	private static final String VERSION_2_1 = "2.1";
	
	public static MigrationProcessor creatProcessor(String vendor, String version) {
		if (VENDOR_TIBCO.equals(vendor) && VERSION_2_1.equals(version)) {
			return new TibcoXPDL21Processor();
		} else {
			throw new IllegalArgumentException("Does not support " + vendor + ":" + version + ", consider contributing!");
		}
	}
}
