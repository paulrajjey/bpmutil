package org.jbpm.migration.processor.dom;

import static org.joox.JOOX.$;
import static org.joox.JOOX.attr;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Sets the size of the standard elements; pads certain elements from the GPD to 
 * the BPMN2.
 * 
 * @author bradsdavis@gmail.com
 *
 */
public class SizeShapesProcessor implements DomProcessor {

	private static final Logger LOG = Logger.getLogger(SizeShapesProcessor.class);
	
	private Map<String, Double> nodeSizes = new HashMap<String, Double>();
	
    public SizeShapesProcessor() {
    	this.setSize("startEvent", 30.0)
    	.setSize("endEvent", 28.0)
    	.setSize("exclusiveGateway", 40.0)
    	.setSize("parallelGateway", 40.0)
    	.setSize("intermediateCatchEvent", 40.0)
    	.setSize("scriptTask", 80.0)
    	.setSize("userTask", 80.0)
    	.setSize("callActivity", 80.0);
    }
    
	public SizeShapesProcessor setSize(String nodeName, Double size) {
		nodeSizes.put(nodeName, size);
		return this;
	}
	
	@Override
	public Document process(Document bpmn) {
		
		for (Entry<String, Double> entry : nodeSizes.entrySet()) {
			for(Element sequenceFlow : $(bpmn).find(entry.getKey()).get()) {
				//find the BPMNShape with the source and targets
				String id = $(sequenceFlow).attr("id");
				LOG.debug("Setting BPMNS shape " + id + " size to " + entry.getValue());
				setBpmnShapeHeight(bpmn, id, entry.getValue());
				setBpmnShapeWidth(bpmn, id, entry.getValue());
			}
		}
		
		return bpmn;
	}
	
	private void setBpmnShapeWidth(Document bpmn, String sourceRef, Double width) {
		$(bpmn).find("BPMNShape").filter(attr("bpmnElement", sourceRef)).child("Bounds").attr("width", width.toString());
	}
	private void setBpmnShapeHeight(Document bpmn, String sourceRef, Double height) {
		$(bpmn).find("BPMNShape").filter(attr("bpmnElement", sourceRef)).child("Bounds").attr("height", height.toString());
	}
	
}
