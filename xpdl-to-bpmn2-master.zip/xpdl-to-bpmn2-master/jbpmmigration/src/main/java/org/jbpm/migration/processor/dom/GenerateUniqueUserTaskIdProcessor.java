package org.jbpm.migration.processor.dom;

import org.joox.Match;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;

import java.util.concurrent.atomic.AtomicInteger;

import static org.jbpm.migration.util.CountedMapUtil.toCountedMapFromIds;
import static org.joox.JOOX.$;
import static org.joox.JOOX.ids;
import static org.joox.JOOX.matchText;
import static org.joox.JOOX.or;
import static org.joox.JOOX.tag;

/**
 * Makes potentialOwner, input/outputSets, resourceAssignmentExpression, and formalExpression ids globally unique
 * IDs are generated ONLY for values that need it
 * 
 * @author bradsdavis@gmail.com
 * @author abaxter@redhat.com
 *
 */
public class GenerateUniqueUserTaskIdProcessor implements DomProcessor {

	private static final Logger LOG = LoggerFactory.getLogger(GenerateUniqueUserTaskIdProcessor.class);
	
	@Override
	public Document process(Document document) {
		Match bpmn = $(document);
		setUniqueIds(bpmn.find("potentialOwner"));
		setUniqueIds(bpmn.find("potentialOwner").children("resourceAssignmentExpression"));
		setUniqueIds(bpmn.find("potentialOwner").children("resourceAssignmentExpression").children("formalExpression"));
    	return document;
	}

	private void setUniqueIds(Match elements) {
		toCountedMapFromIds(elements.each()).entrySet().stream()
				.filter( e -> e.getValue() > 1)
				.forEach(e -> {
					String id = e.getKey();
					Integer count = e.getValue();
					AtomicInteger idCount = new AtomicInteger(0);
					LOG.debug("Multiple ioSpecifications sharing the same id {}: {}", id, count);
					elements.filter(ids(id)).forEach(
							m -> $(m).attr("id", id + "_" + + idCount.addAndGet(1))
					);
				});
	}

}
