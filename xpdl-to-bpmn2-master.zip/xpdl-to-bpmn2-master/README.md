# XPDL to BPMN2 Migration

## TODO
* Write better README
* Continue to break out the mega xsl (XPDLtoBPMN file) into smaller xsl
* Handle multiple incoming/outgoing sequence flows to non-gateway nodes correctly


### Instructions (Windup)

_Coming Soon_

### Instructions (Java)

In order to execute the transformation on an XPDL 2.1 file name `in.xpdl` and output the result processes to a new directory labeled `generated` , navigate to the `jbpmmigration` project and execute the following command:

```bash
[selrahal@localhost jbpmmigration]$ mvn exec:java -Dexec.mainClass="org.jbpm.migration.main.JbpmMigration" -Dexec.args="in.xpdl generated"
```
